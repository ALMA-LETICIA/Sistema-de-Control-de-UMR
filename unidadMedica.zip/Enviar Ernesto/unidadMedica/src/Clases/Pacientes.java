package clases;

/**
 *
 * @author ERNESTO
 */

public class Pacientes {
    private String numeroSeguro;
    private int id_datosP;

    public Pacientes(String numeroSeguro, int id_datosP) {
        this.numeroSeguro = numeroSeguro;
        this.id_datosP = id_datosP;
    }

    public String getNumeroSeguro() {
        return numeroSeguro;
    }

    public void setNumeroSeguro(String numeroSeguro) {
        this.numeroSeguro = numeroSeguro;
    }

    public int getId_datosP() {
        return id_datosP;
    }

    public void setId_datosP(int id_datosP) {
        this.id_datosP = id_datosP;
    }
    
    
}
