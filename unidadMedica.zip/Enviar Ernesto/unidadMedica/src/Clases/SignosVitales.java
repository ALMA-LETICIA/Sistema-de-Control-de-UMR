
package clases;

/**
 *
 * @author ERNESTO
 */
public class SignosVitales {
    private String tipoSangre;
    private double peso;
    private double talla;
    private double indicemasacorporal;
    private int id_consulta;

    public SignosVitales(String tipoSangre, double peso, double talla, double indicemasacorporal, int id_consulta) {
        this.tipoSangre = tipoSangre;
        this.peso = peso;
        this.talla = talla;
        this.indicemasacorporal = indicemasacorporal;
        this.id_consulta = id_consulta;
    }

    public String getTipoSangre() {
        return tipoSangre;
    }

    public void setTipoSangre(String tipoSangre) {
        this.tipoSangre = tipoSangre;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getTalla() {
        return talla;
    }

    public void setTalla(double talla) {
        this.talla = talla;
    }

    public double getIndicemasacorporal() {
        return indicemasacorporal;
    }

    public void setIndicemasacorporal(double indicemasacorporal) {
        this.indicemasacorporal = indicemasacorporal;
    }

    public int getId_consulta() {
        return id_consulta;
    }

    public void setId_consulta(int id_consulta) {
        this.id_consulta = id_consulta;
    }

    
    
}
