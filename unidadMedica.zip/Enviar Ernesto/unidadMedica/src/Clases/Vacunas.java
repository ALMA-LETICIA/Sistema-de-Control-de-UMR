
package clases;

/**
 *
 * @author ERNESTO
 */
public class Vacunas {
    private String descripcion;
    private int id_Paciente;

    public Vacunas(String descripcion, int id_Paciente) {
        this.descripcion = descripcion;
        this.id_Paciente = id_Paciente;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getId_Paciente() {
        return id_Paciente;
    }

    public void setId_Paciente(int id_Paciente) {
        this.id_Paciente = id_Paciente;
    }
    
    
    
}
