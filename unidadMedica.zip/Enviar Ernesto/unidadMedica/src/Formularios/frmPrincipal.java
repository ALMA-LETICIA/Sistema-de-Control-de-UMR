package formularios;

import clases.Datos;
import clases.DesktopConFondo;
import com.bulenkov.darcula.DarculaLaf;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.PropertyVetoException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class frmPrincipal extends javax.swing.JFrame {

    private Datos misDatos;
    private int perfil;
    private String clave;
    private String usuario;

    public void setUsuario(String usuario) {
        this.usuario = usuario;
//        String titulo = "UMR - Usuario: " + this.usuario;
//        if (perfil == 1) {
//            titulo = titulo + " - Perfil: doctor";
//        } else {
//            titulo = titulo + " - Perfil: enfermero";
//        }
//        this.setTitle(titulo);
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public void setDatos(Datos d) {
        this.misDatos = d;
    }

    public frmPrincipal() {
        initComponents();
        setIcono();
        cerrar(); //añadimos el listener de cierre al constructor
    }

//    public void setPerfil(int perfil) {
//        this.perfil = perfil;
//    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        dpnEscritorio = new DesktopConFondo();
        jMenuBar1 = new javax.swing.JMenuBar();
        mnuArchivo = new javax.swing.JMenu();
        mnuArchivoDatosP = new javax.swing.JMenuItem();
        mnuArchivoMedicos = new javax.swing.JMenuItem();
        mnuArchivoEnfermeros = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        mnuArchivoPacientes = new javax.swing.JMenuItem();
        mnuArchivoVacunas = new javax.swing.JMenuItem();
        mnuArchivoDiaNV = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        mnuArchivoUsuarios = new javax.swing.JMenuItem();
        mnuArchivoCambioClave = new javax.swing.JMenuItem();
        mnuArchivoCambioUsuario = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        mnuArchivoSalir = new javax.swing.JMenuItem();
        mnuMovimientos = new javax.swing.JMenu();
        mnuCertificadoMedico = new javax.swing.JMenuItem();
        mnuAyuda = new javax.swing.JMenu();
        mnuAcercaDe = new javax.swing.JMenuItem();

        jMenuItem1.setText("jMenuItem1");

        jMenuItem3.setText("jMenuItem3");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Sistema de Control de la UMR");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        dpnEscritorio.setBackground(new java.awt.Color(153, 255, 153));
        dpnEscritorio.setForeground(new java.awt.Color(132, 132, 132));

        jMenuBar1.setBackground(new java.awt.Color(153, 255, 153));

        mnuArchivo.setBackground(new java.awt.Color(153, 255, 153));
        mnuArchivo.setForeground(new java.awt.Color(0, 102, 51));
        mnuArchivo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/folder.png"))); // NOI18N
        mnuArchivo.setText("Registros");

        mnuArchivoDatosP.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_MASK));
        mnuArchivoDatosP.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/datos personales.png"))); // NOI18N
        mnuArchivoDatosP.setText("Datos Personales");
        mnuArchivoDatosP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuArchivoDatosPActionPerformed(evt);
            }
        });
        mnuArchivo.add(mnuArchivoDatosP);

        mnuArchivoMedicos.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_M, java.awt.event.InputEvent.CTRL_MASK));
        mnuArchivoMedicos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/med.png"))); // NOI18N
        mnuArchivoMedicos.setText("Médicos");
        mnuArchivoMedicos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuArchivoMedicosActionPerformed(evt);
            }
        });
        mnuArchivo.add(mnuArchivoMedicos);

        mnuArchivoEnfermeros.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_E, java.awt.event.InputEvent.CTRL_MASK));
        mnuArchivoEnfermeros.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/domicilio.png"))); // NOI18N
        mnuArchivoEnfermeros.setText("Enfermeros");
        mnuArchivoEnfermeros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuArchivoEnfermerosActionPerformed(evt);
            }
        });
        mnuArchivo.add(mnuArchivoEnfermeros);

        jMenu1.setText("Consultas");

        jMenuItem2.setText("Registrar Consulta");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem4.setText("Registrar Signos Vitales");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem4);

        jMenuItem5.setText("Registrar Malestares");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem5);

        jMenuItem6.setText("Suministrar Medicamentos");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem6);

        mnuArchivo.add(jMenu1);

        mnuArchivoPacientes.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_P, java.awt.event.InputEvent.CTRL_MASK));
        mnuArchivoPacientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/group_add.png"))); // NOI18N
        mnuArchivoPacientes.setText("Pacientes");
        mnuArchivoPacientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuArchivoPacientesActionPerformed(evt);
            }
        });
        mnuArchivo.add(mnuArchivoPacientes);

        mnuArchivoVacunas.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_V, java.awt.event.InputEvent.CTRL_MASK));
        mnuArchivoVacunas.setText("Vacunas");
        mnuArchivoVacunas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuArchivoVacunasActionPerformed(evt);
            }
        });
        mnuArchivo.add(mnuArchivoVacunas);

        mnuArchivoDiaNV.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        mnuArchivoDiaNV.setText("Dia Nacional de Vacunación");
        mnuArchivoDiaNV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuArchivoDiaNVActionPerformed(evt);
            }
        });
        mnuArchivo.add(mnuArchivoDiaNV);
        mnuArchivo.add(jSeparator1);

        mnuArchivoUsuarios.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_U, java.awt.event.InputEvent.CTRL_MASK));
        mnuArchivoUsuarios.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/status_online.png"))); // NOI18N
        mnuArchivoUsuarios.setText("Usuarios");
        mnuArchivoUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuArchivoUsuariosActionPerformed(evt);
            }
        });
        mnuArchivo.add(mnuArchivoUsuarios);

        mnuArchivoCambioClave.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_W, java.awt.event.InputEvent.CTRL_MASK));
        mnuArchivoCambioClave.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/group_key.png"))); // NOI18N
        mnuArchivoCambioClave.setText("Cambio Clave");
        mnuArchivoCambioClave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuArchivoCambioClaveActionPerformed(evt);
            }
        });
        mnuArchivo.add(mnuArchivoCambioClave);

        mnuArchivoCambioUsuario.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Y, java.awt.event.InputEvent.CTRL_MASK));
        mnuArchivoCambioUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/group.png"))); // NOI18N
        mnuArchivoCambioUsuario.setText("Cambio Usuario");
        mnuArchivoCambioUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuArchivoCambioUsuarioActionPerformed(evt);
            }
        });
        mnuArchivo.add(mnuArchivoCambioUsuario);

        jSeparator2.setForeground(new java.awt.Color(153, 153, 153));
        mnuArchivo.add(jSeparator2);

        mnuArchivoSalir.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, java.awt.event.InputEvent.CTRL_MASK));
        mnuArchivoSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/exit.png"))); // NOI18N
        mnuArchivoSalir.setText("Salir");
        mnuArchivoSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuArchivoSalirActionPerformed(evt);
            }
        });
        mnuArchivo.add(mnuArchivoSalir);

        jMenuBar1.add(mnuArchivo);

        mnuMovimientos.setBackground(new java.awt.Color(153, 255, 153));
        mnuMovimientos.setForeground(new java.awt.Color(0, 102, 51));
        mnuMovimientos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/page_refresh.png"))); // NOI18N
        mnuMovimientos.setText("Movimientos");

        mnuCertificadoMedico.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/invoice.png"))); // NOI18N
        mnuCertificadoMedico.setText("Generar Certificado Méd.");
        mnuCertificadoMedico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuCertificadoMedicoActionPerformed(evt);
            }
        });
        mnuMovimientos.add(mnuCertificadoMedico);

        jMenuBar1.add(mnuMovimientos);

        mnuAyuda.setBackground(new java.awt.Color(153, 255, 153));
        mnuAyuda.setForeground(new java.awt.Color(0, 102, 51));
        mnuAyuda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/ayuda.png"))); // NOI18N
        mnuAyuda.setText("Ayuda");

        mnuAcercaDe.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        mnuAcercaDe.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/information.png"))); // NOI18N
        mnuAcercaDe.setText("Acerca de...");
        mnuAcercaDe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuAcercaDeActionPerformed(evt);
            }
        });
        mnuAyuda.add(mnuAcercaDe);

        jMenuBar1.add(mnuAyuda);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dpnEscritorio, javax.swing.GroupLayout.DEFAULT_SIZE, 780, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dpnEscritorio, javax.swing.GroupLayout.DEFAULT_SIZE, 0, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mnuArchivoPacientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuArchivoPacientesActionPerformed
        try {
            frmPacientes misPacientes = new frmPacientes();
            misPacientes.setDatos(misDatos);
            dpnEscritorio.add(misPacientes);
            Dimension dpnSize = dpnEscritorio.getSize();
            Dimension frameSize = misPacientes.getSize();
            misPacientes.setLocation(
                    (dpnSize.width - frameSize.width) / 2,
                    (dpnSize.height - frameSize.height) / 2);
            misPacientes.setMaximum(true);
            misPacientes.show();
        } catch (PropertyVetoException ex) {
            Logger.getLogger(frmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_mnuArchivoPacientesActionPerformed

    private void mnuCertificadoMedicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuCertificadoMedicoActionPerformed
        frmCertificadoMedico misUsuarios = new frmCertificadoMedico();
            misUsuarios.setDatos(misDatos);
            dpnEscritorio.add(misUsuarios);
            //Dimension dpnSize = dpnEscritorio.getSize();
            //Dimension frameSize = misUsuarios.getSize();
            //misUsuarios.setLocation(
            //        (dpnSize.width - frameSize.width) / 2,
            //        (dpnSize.height - frameSize.height) / 2);
            //misUsuarios.setMaximum(true);
            misUsuarios.show();
    }//GEN-LAST:event_mnuCertificadoMedicoActionPerformed

    private void mnuArchivoUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuArchivoUsuariosActionPerformed
        
        try {
            frmUsuarios misUsuarios = new frmUsuarios();
            misUsuarios.setDatos(misDatos);
            dpnEscritorio.add(misUsuarios);
            Dimension dpnSize = dpnEscritorio.getSize();
            Dimension frameSize = misUsuarios.getSize();
            misUsuarios.setLocation(
                    (dpnSize.width - frameSize.width) / 2,
                    (dpnSize.height - frameSize.height) / 2);
            misUsuarios.setMaximum(true);
            misUsuarios.show();
        } catch (PropertyVetoException ex) {
            Logger.getLogger(frmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_mnuArchivoUsuariosActionPerformed

    private void mnuArchivoSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuArchivoSalirActionPerformed
        salir();
    }//GEN-LAST:event_mnuArchivoSalirActionPerformed

    private void mnuArchivoEnfermerosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuArchivoEnfermerosActionPerformed
        try {
            frmEnfermeros misEnfermeros = new frmEnfermeros();
            misEnfermeros.setDatos(misDatos);
            dpnEscritorio.add(misEnfermeros);
            Dimension dpnSize = dpnEscritorio.getSize();
            Dimension frameSize = misEnfermeros.getSize();
            misEnfermeros.setLocation(
                    (dpnSize.width - frameSize.width) / 2,
                    (dpnSize.height - frameSize.height) / 2);
            misEnfermeros.setMaximum(true);
            misEnfermeros.show();
        } catch (PropertyVetoException ex) {
            Logger.getLogger(frmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_mnuArchivoEnfermerosActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        //Establece la imagen de fondo
        ((DesktopConFondo) dpnEscritorio).setImagen("/images/imgFondo.png");

        //Establece permisos
//        if (perfil == 2) { //Si es empleado eliminamos permisos
//            mnuArchivoPacientes.setEnabled(false);
//            mnuArchivoEnfermeros.setEnabled(false);
//            mnuArchivoUsuarios.setEnabled(false);
//            mnuCertificadoMedico.setEnabled(false);
//        }
    }//GEN-LAST:event_formWindowOpened

    private void mnuArchivoCambioUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuArchivoCambioUsuarioActionPerformed
        //Ocultamos el formulario principal
        this.setVisible(false);
        frmLogin miLogin = new frmLogin();
        miLogin.setDatos(misDatos);
        miLogin.setCambioUsuario(true);
        
        //Centramos el formulario en pantalla
        miLogin.setLocationRelativeTo(null);
        miLogin.setVisible(true);
    }//GEN-LAST:event_mnuArchivoCambioUsuarioActionPerformed

    private void mnuArchivoCambioClaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuArchivoCambioClaveActionPerformed
        frmCambioClave miCambio = new frmCambioClave(this, rootPaneCheckingEnabled);
        miCambio.setClave(clave);
        miCambio.setUsuario(usuario);
        miCambio.setDatos(misDatos);
        //Mostramos el formulario cambioClave centrado en la pantalla
        miCambio.setLocationRelativeTo(this);
        miCambio.setVisible(rootPaneCheckingEnabled);
    }//GEN-LAST:event_mnuArchivoCambioClaveActionPerformed

    private void mnuAcercaDeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuAcercaDeActionPerformed
        frmAcercaDe acercaDe = new frmAcercaDe(this, rootPaneCheckingEnabled);
        acercaDe.setLocationRelativeTo(this);
        acercaDe.setVisible(rootPaneCheckingEnabled);
    }//GEN-LAST:event_mnuAcercaDeActionPerformed

    private void mnuArchivoDatosPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuArchivoDatosPActionPerformed
        try {
            frmDatosPersonales misDatosP = new frmDatosPersonales();
            misDatosP.setDatos(misDatos);
            dpnEscritorio.add(misDatosP);
            Dimension dpnSize = dpnEscritorio.getSize();
            Dimension frameSize = misDatosP.getSize();
            misDatosP.setLocation(
                    (dpnSize.width - frameSize.width) / 2,
                    (dpnSize.height - frameSize.height) / 2);
            misDatosP.setMaximum(true);
            misDatosP.show();
        } catch (PropertyVetoException ex) {
            Logger.getLogger(frmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_mnuArchivoDatosPActionPerformed

    private void mnuArchivoMedicosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuArchivoMedicosActionPerformed
        try {
            frmMedicos misMedicos = new frmMedicos();
            misMedicos.setDatos(misDatos);
            dpnEscritorio.add(misMedicos);
            Dimension dpnSize = dpnEscritorio.getSize();
            Dimension frameSize = misMedicos.getSize();
            misMedicos.setLocation(
                    (dpnSize.width - frameSize.width) / 2,
                    (dpnSize.height - frameSize.height) / 2);
            misMedicos.setMaximum(true);
            misMedicos.show();
        } catch (PropertyVetoException ex) {
            Logger.getLogger(frmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_mnuArchivoMedicosActionPerformed

    private void mnuArchivoVacunasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuArchivoVacunasActionPerformed
        try {
            frmVacunas misVacuans = new frmVacunas();
            misVacuans.setDatos(misDatos);
            dpnEscritorio.add(misVacuans);
            Dimension dpnSize = dpnEscritorio.getSize();
            Dimension frameSize = misVacuans.getSize();
            misVacuans.setLocation(
                    (dpnSize.width - frameSize.width) / 2,
                    (dpnSize.height - frameSize.height) / 2);
            misVacuans.setMaximum(true);
            misVacuans.show();
        } catch (PropertyVetoException ex) {
            Logger.getLogger(frmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_mnuArchivoVacunasActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        // TODO add your handling code here:
        try {
            frmConsultas misConsultas = new frmConsultas();
            misConsultas.setDatos(misDatos);
            dpnEscritorio.add(misConsultas);
            Dimension dpnSize = dpnEscritorio.getSize();
            Dimension frameSize = misConsultas.getSize();
            misConsultas.setLocation(
                    (dpnSize.width - frameSize.width) / 2,
                    (dpnSize.height - frameSize.height) / 2);
            misConsultas.setMaximum(true);
            misConsultas.show();
        } catch (PropertyVetoException ex) {
            Logger.getLogger(frmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        // TODO add your handling code here:
        try {
            frmSignosVitales misSignos = new frmSignosVitales();
            misSignos.setDatos(misDatos);
            dpnEscritorio.add(misSignos);
            Dimension dpnSize = dpnEscritorio.getSize();
            Dimension frameSize = misSignos.getSize();
            misSignos.setLocation(
                    (dpnSize.width - frameSize.width) / 2,
                    (dpnSize.height - frameSize.height) / 2);
            misSignos.setMaximum(true);
            misSignos.show();
        } catch (PropertyVetoException ex) {
            Logger.getLogger(frmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
        // TODO add your handling code here:
        try {
            frmMalestares misMalestares = new frmMalestares();
            misMalestares.setDatos(misDatos);
            dpnEscritorio.add(misMalestares);
            Dimension dpnSize = dpnEscritorio.getSize();
            Dimension frameSize = misMalestares.getSize();
            misMalestares.setLocation(
                    (dpnSize.width - frameSize.width) / 2,
                    (dpnSize.height - frameSize.height) / 2);
            misMalestares.setMaximum(true);
            misMalestares.show();
        } catch (PropertyVetoException ex) {
            Logger.getLogger(frmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        // TODO add your handling code here:
        try {
            frmMedicamentos misMedicamentos = new frmMedicamentos();
            misMedicamentos.setDatos(misDatos);
            dpnEscritorio.add(misMedicamentos);
            Dimension dpnSize = dpnEscritorio.getSize();
            Dimension frameSize = misMedicamentos.getSize();
            misMedicamentos.setLocation(
                    (dpnSize.width - frameSize.width) / 2,
                    (dpnSize.height - frameSize.height) / 2);
            misMedicamentos.setMaximum(true);
            misMedicamentos.show();
        } catch (PropertyVetoException ex) {
            Logger.getLogger(frmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void mnuArchivoDiaNVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuArchivoDiaNVActionPerformed
        // TODO add your handling code here:
        try {
            frmDiaVacunacion miDiaVacuna = new frmDiaVacunacion();
            miDiaVacuna.setDatos(misDatos);
            dpnEscritorio.add(miDiaVacuna);
            Dimension dpnSize = dpnEscritorio.getSize();
            Dimension frameSize = miDiaVacuna.getSize();
            miDiaVacuna.setLocation(
                    (dpnSize.width - frameSize.width) / 2,
                    (dpnSize.height - frameSize.height) / 2);
            miDiaVacuna.setMaximum(true);
            miDiaVacuna.show();
        } catch (PropertyVetoException ex) {
            Logger.getLogger(frmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_mnuArchivoDiaNVActionPerformed

    public void loadTheme() {
        try {
            UIManager.setLookAndFeel(new DarculaLaf());

        } catch (Exception ex) {
            Logger.getLogger(frmPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
        SwingUtilities.updateComponentTreeUI(this);
    }

    private void setIcono() {
        // obtenemos la ruta de la imagen
       // URL url = getClass().getResource("/images/32x32.png");
         URL url = getClass().getResource("/images/imss.png");
        ImageIcon img = new ImageIcon(url);
        // ponemos la imagen como icono
        setIconImage(img.getImage());
    }

    public final void cerrar() {
        try {
            this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
            addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent e) {
                    salir();
                }
            });
        } catch (Exception e) {
            Logger.getLogger(frmPrincipal.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    private void salir() {
        Object[] options = {"Sí", "No"};
        int respuesta = JOptionPane.showOptionDialog(
                rootPane,
                "¿Está seguro de salir de la aplicación?",
                "Salir de la aplicación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE,
                null, options, options[1]);
        if (respuesta != 0) {
            return;
        }
        System.exit(0);
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JDesktopPane dpnEscritorio;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JMenuItem mnuAcercaDe;
    private javax.swing.JMenu mnuArchivo;
    private javax.swing.JMenuItem mnuArchivoCambioClave;
    private javax.swing.JMenuItem mnuArchivoCambioUsuario;
    private javax.swing.JMenuItem mnuArchivoDatosP;
    private javax.swing.JMenuItem mnuArchivoDiaNV;
    private javax.swing.JMenuItem mnuArchivoEnfermeros;
    private javax.swing.JMenuItem mnuArchivoMedicos;
    private javax.swing.JMenuItem mnuArchivoPacientes;
    private javax.swing.JMenuItem mnuArchivoSalir;
    private javax.swing.JMenuItem mnuArchivoUsuarios;
    private javax.swing.JMenuItem mnuArchivoVacunas;
    private javax.swing.JMenu mnuAyuda;
    private javax.swing.JMenuItem mnuCertificadoMedico;
    private javax.swing.JMenu mnuMovimientos;
    // End of variables declaration//GEN-END:variables
}
