/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Alma
 */
public class Medicamentos {
    
    private String nombremedicamento;
    private String recomendaciones;
    private int id_malestar;

    public Medicamentos(String nombremedicamento, String recomendaciones, int id_malestar) {
        this.nombremedicamento = nombremedicamento;
        this.recomendaciones = recomendaciones;
        this.id_malestar = id_malestar;
    }

    public String getNombremedicamento() {
        return nombremedicamento;
    }

    public void setNombremedicamento(String nombremedicamento) {
        this.nombremedicamento = nombremedicamento;
    }

    public String getRecomendaciones() {
        return recomendaciones;
    }

    public void setRecomendaciones(String recomendaciones) {
        this.recomendaciones = recomendaciones;
    }

    public int getId_malestar() {
        return id_malestar;
    }

    public void setId_malestar(int id_malestar) {
        this.id_malestar = id_malestar;
    }
    
    
    
}
