
package clases;

/**
 *
 * @author Alma
 */
public class Medicos {
    private String cedulaProfesional;
    private int id_datosp;

    public Medicos(String cedulaProfesional, int id_datosp) {
        this.cedulaProfesional = cedulaProfesional;
        this.id_datosp = id_datosp;
    }

    public String getCedulaProfesional() {
        return cedulaProfesional;
    }

    public void setCedulaProfesional(String cedulaProfesional) {
        this.cedulaProfesional = cedulaProfesional;
    }

    public int getId_datosp() {
        return id_datosp;
    }

    public void setId_datosp(int id_datosp) {
        this.id_datosp = id_datosp;
    }

}