
package clases;

/**
 *
 * @author Alma
 */
public class Malestares {
    private String descripcion;
    private int id_consulta;

    public Malestares(String descripcion, int id_consulta) {
        this.descripcion = descripcion;
        this.id_consulta = id_consulta;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getId_consulta() {
        return id_consulta;
    }

    public void setId_consulta(int id_consulta) {
        this.id_consulta = id_consulta;
    }
    
    
    
}
